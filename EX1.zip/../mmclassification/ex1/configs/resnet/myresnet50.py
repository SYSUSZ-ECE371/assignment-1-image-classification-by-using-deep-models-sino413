_base_ = [
    '../_base_/models/myresnet50.py', '../_base_/datasets/myimagenet.py',
    '../_base_/schedules/myimagenet.py', '../_base_/default_runtime.py'
]


